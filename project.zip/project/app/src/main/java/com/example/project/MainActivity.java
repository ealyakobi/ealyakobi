package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

import java.sql.Time;
import java.sql.Timestamp;

import pl.droidsonroids.gif.GifImageView;

public class MainActivity extends AppCompatActivity {
    private TextView num;
    private ImageButton castle;
    private ImageButton cloud;
    public static int numInt = 0;
    public String value = "0";
    public String value2 = "0";
    private int check = 0;
    private ImageView gif;
    private CountDownTimer time;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        num = findViewById(R.id.num);
        numInt = Integer.valueOf(num.getText().toString());
        castle = findViewById(R.id.castle_btn);
        cloud = findViewById(R.id.cloud);
        gif = findViewById(R.id.gif);
        value = getIntent().getStringExtra("value");
        value2 = getIntent().getStringExtra("value2");
        if (value2 == null) {
            value2 = "0";
            value = "0";
        }
        if (Integer.parseInt(value2) >= 1) {
            Glide.with(getBaseContext())
                    .load(R.drawable.stickman)
                    .into(gif);
        }
            time = new CountDownTimer(3000, 1000) {
                @Override
                public void onTick(long l) {
                    Log.d("miao","miao");
                }

                @Override
                public void onFinish() {
                    num.setText(String.valueOf(Integer.parseInt(value) + 1));
                    start();
                }

            }.start();
            num.setText(value);
            final Intent shopp = new Intent(this, shop.class);
            castle.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    value = String.valueOf(Integer.parseInt(value)+1);
                    num.setText("" + value);
                }
            });
            cloud.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View
                                            view) {
                    shopp.putExtra("value", num.getText().toString());
                    startActivity(shopp);

                }
            });
    }}