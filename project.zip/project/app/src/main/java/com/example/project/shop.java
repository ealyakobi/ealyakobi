package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class shop extends AppCompatActivity {

    private ImageButton back;
    private ImageButton stickbuy;
    private TextView balance;
    private String value = "0";
    private String value2 = "0";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop);
        back = findViewById(R.id.back);
        stickbuy = findViewById(R.id.stickbuy);
        balance = findViewById(R.id.balance);
        value = getIntent().getStringExtra("value");
        balance.setText(value);
        final Intent intent = new Intent(this, MainActivity.class);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent.putExtra("value",balance.getText().toString());
                intent.putExtra("value2",balance.getText().toString());
                startActivity(intent);


          }
        });
        stickbuy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Integer.valueOf(value) - 10 >= 0)
                {
                    value = String.valueOf(Integer.valueOf(value) - 10);
                    balance.setText(value);
                    value2 = String.valueOf(Integer.valueOf(value2) + 1);;
                }
                else
                {
                    value2 = "-1";
                    Toast.makeText(getApplicationContext(),
                        "Insufficient funds",
                        Toast.LENGTH_LONG).show();
                }

            }
});}}